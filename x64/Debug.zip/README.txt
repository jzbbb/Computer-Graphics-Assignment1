Assignment 1 Keyboard / Mouse Events  

 - Name: 	蒋泽波	
 - Student ID:202008010219	

Manipulation:
鼠标 “移动”：转动整个布局视角
鼠标 “滑轮”：上滑放大视角，下滑缩小视角
Key "Esc": exit
Key "W": 视角前移
Key "A": 视角左移
Key "S": 视角后移
Key "D": 视角右移
Key "UP": 人物上移
Key "DOWN": 人物下移
Key "LEFT": 人物左移
Key "RIGHT": 人物右移
Key "SPACE": 人物跳跃
Key "ENTER": 人物身体换色
Key "Q": 透视投影参数宽高比增大
Key "E": 透视投影参数宽高比减小

说明：左下角和右上角有两个传送门，人物走到对应位置可以传到相应传送门。
人物只能在棋盘内活动，超过布局大小时会移动到对面的位置
